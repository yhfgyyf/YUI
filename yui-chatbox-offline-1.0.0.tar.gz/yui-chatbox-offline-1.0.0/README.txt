YUI ChatBox v1.0.0 - Offline Installation Package
======================================================================

This package contains everything needed to install YUI ChatBox
without internet access, including all Python dependencies and
pre-built frontend static files.

Contents:
---------
- yuichatbox-1.0.0-py3-none-any.whl : Pre-built YUI ChatBox package
- wheels/ : All Python dependencies (29 packages)
- static/ : Pre-built frontend static files (HTML/CSS/JS)
- install.sh : Automated installation script (Linux/macOS)
- install.bat : Automated installation script (Windows)
- README.txt : This file

System Requirements:
--------------------
- Python 3.8 or later
- pip (usually comes with Python)
- Linux, macOS, or Windows
- NO internet connection required
- NO Node.js or npm required (frontend pre-built)

Installation Instructions:
--------------------------

Linux/macOS:
  tar -xzf yui-chatbox-offline-1.0.0.tar.gz
  cd yui-chatbox-offline-1.0.0
  ./install.sh

Windows:
  1. Extract yui-chatbox-offline-1.0.0.tar.gz
  2. Open Command Prompt in the extracted folder
  3. Run: install.bat

After Installation:
-------------------
1. Initialize configuration:
   python -m yuichatbox init-config

2. Edit .env file with your API credentials:
   - OPENAI_API_KEY: Your API key
   - OPENAI_BASE_URL: API endpoint URL
   Example:
     OPENAI_BASE_URL=https://api.openai.com/v1
     OPENAI_API_KEY=sk-...

3. Start the server:
   python -m yuichatbox serve

4. Open your browser and visit:
   http://localhost:8001

Features:
---------
- Multi-model support (OpenAI, DeepSeek, Claude, etc.)
- Conversation management with folders
- Message search and filtering
- Dark/Light theme
- Markdown and code highlighting
- Reasoning visualization for thinking models
- Database-backed persistence (SQLite)
- No external services required

Database:
---------
YUI ChatBox uses SQLite for data persistence. The database file
will be created at:
  ~/.yui/chatbox.db

All conversations, settings, and model sources are stored locally.

Troubleshooting:
----------------
- If 'yui' command not found, use:
  python -m yuichatbox --help

- To check installation:
  python -m yuichatbox --version

- For database issues:
  The database will be automatically created and migrated
  on first run

- For more help:
  python -m yuichatbox --help

Support:
--------
For issues, please check:
https://github.com/yourusername/yui-chatbox

Version Info:
-------------
Package Version: 1.0.0
Build Date: 2026-01-11 12:16:18
Python Dependencies: 29 packages
Static Files: 3 files
