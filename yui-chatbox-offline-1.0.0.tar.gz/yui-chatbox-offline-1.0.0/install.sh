#!/bin/bash
# Offline installation script for YUI ChatBox

set -e

echo "======================================================================"
echo "YUI ChatBox - Offline Installation"
echo "======================================================================"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.8 or later"
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "Found Python ${PYTHON_VERSION}"

# Check pip
if ! python3 -m pip --version &> /dev/null; then
    echo "ERROR: pip is not installed"
    echo "Please install pip first"
    exit 1
fi

# Install from local wheels
echo ""
echo "Installing YUI ChatBox and dependencies from local wheels..."
echo "This may take a few minutes..."
python3 -m pip install --no-index --find-links=./wheels yuichatbox-*.whl

# Verify installation
echo ""
echo "Verifying installation..."
if python3 -m yuichatbox --version &> /dev/null; then
    echo "✓ Installation verified successfully"
else
    echo "✗ Installation verification failed"
    exit 1
fi

echo ""
echo "======================================================================"
echo "Installation complete!"
echo "======================================================================"
echo ""
echo "Next steps:"
echo "1. Initialize configuration:"
echo "   python3 -m yuichatbox init-config"
echo ""
echo "2. Edit .env file with your API credentials:"
echo "   nano .env"
echo "   (Set OPENAI_API_KEY and OPENAI_BASE_URL)"
echo ""
echo "3. Start the server:"
echo "   python3 -m yuichatbox serve"
echo ""
echo "4. Open your browser and visit:"
echo "   http://localhost:8001"
echo ""
echo "For more help, run: python3 -m yuichatbox --help"
echo "======================================================================"
